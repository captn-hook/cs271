/****************************************
 * C-ploration 3 for CS 271
 * 
 * [NAME] $YOUR_NAME$
 * [TERM] FALL $YEAR$
 * 
 ****************************************/
 
int main()
{	
	return 1;
}
